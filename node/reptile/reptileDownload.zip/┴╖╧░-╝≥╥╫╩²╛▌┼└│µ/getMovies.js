const axios = require("axios");
const cheerio = require("cheerio");
/**
 * 得到html字符串
 */

async function getMoviesList(){
    const html = await axios("https://movie.douban.com/chart");
    const $ = cheerio.load(html.data);
    let trs = $("tr.item");
    const moviesList = [];
    for(let i = 0; i <trs.length; i ++){
        let tr = trs[i];
        // 得到每个movies里面的数据
        let trData = getMoviesData($(tr));
        moviesList.push(trData);
    }
    return moviesList;
}

/**
 * 得到每一条movies的name,img,note值
 * @param {*} tr 
 */
function getMoviesData(tr){
    let name = tr.find(".pl2 a").text();
    let img = tr.find(".nbg img").attr("src");
    let note = tr.find("p.pl").text();
    name = name.replace(/\s/g, "");
    name = name.split("/")[0];
    return {
        name,
        img,
        note
    }
}

module.exports = getMoviesList;
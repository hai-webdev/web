const getMovies = require("./getMovies");
const fs = require("fs");
module.exports = getMovies().then((data)=>{
    const json = JSON.stringify(data)
    fs.writeFile("moviesList.json", json, ()=>{
        console.log("采集完成！");
    })
})
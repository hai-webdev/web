const util = require("./util");
const arr = pokerArr = util.createPoker();
const pokerRandomArr = util.sortRandom(arr);

const player1 = "\n玩家1的牌:\n\n" + util.splitArr(pokerRandomArr.slice(0, 17));
const player2 = "\n玩家2的牌:\n\n" +  util.splitArr(pokerRandomArr.slice(17, 34));
const player3 = "\n玩家3的牌:\n\n" +  util.splitArr(pokerRandomArr.slice(34, 51));
const desk = "\n桌面上的牌:\n\n" +  util.splitArr(pokerRandomArr.slice(51, 54));

console.log(player1,player2,player3,desk);

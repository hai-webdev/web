const Poker = require("./poker");
module.exports = {
    /**
     * 将数组打乱
     * @param {Array} arr 数组
     */
    sortRandom(arr) {
        return arr.sort((a, b) => {
            return Math.random() - 0.5;
        });

    },
    createPoker() {
        const pokerArr = [];
        for (let i = 1; i <= 13; i++) {
            for (let j = 1; j <= 4; j++) {
                pokerArr.push(new Poker(j, i).toString());
            }
        }
        pokerArr.push(new Poker(-1, 14).toString())
        pokerArr.push(new Poker(-1, 15).toString());
        return pokerArr;
    },
    splitArr(arr){
        let str = "";
        for (const item of arr) {
            str += item + ", ";
        }
        return str;
    }
}